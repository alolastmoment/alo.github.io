(() => {
  api.system.observeData(function (systemData) {
    loadTime(systemData);
  });
  api.resources.observeData(function (resourcesData) {
    loadBattery(resourcesData);
  });
  applyConfiguration();
})();

function loadTime(systemData) {
  time.init({
    refresh: 5000,
    twentyfour: systemData.isTwentyFourHourTimeEnabled,
    callback: function (time) {
      document.getElementById(
        "date"
      ).innerHTML = `It's ${time.dayText()}, ${time.monthText()} ${time.dateNth()}`;
      document.getElementById(
        "time"
      ).innerHTML = `Current time ${time.hour()}:${time.minute()}`;
    },
  });
}

function loadBattery(resourcesData) {
  document.getElementById(
    "batt"
  ).innerHTML = `Battery life ${resourcesData.battery.percentage}%`;
}

function applyConfiguration() {
  isDateHidden();
  isBatteryHidden();
  isClockHidden();
  setCardProperties();
  setTheme();
  setFrostyBlur();
  setFont();
}

function isDateHidden() {
  if (config.isDateHidden)
    return (document.getElementById("date").style.display = "none");
  return;
}

function isBatteryHidden() {
  if (config.isBatteryHidden)
    return (document.getElementById("batt").style.display = "none");
  return;
}

function isClockHidden() {
  if (config.isClockHidden)
    return (document.getElementById("time").style.display = "none");
  return;
}

function setCardProperties() {
  let root = document.querySelector(":root");
  root.style.setProperty("--cardHeight", `${config.cardHeight}%`);
  root.style.setProperty("--cardWidth", `${config.cardWidth}%`);
  root.style.setProperty("--cardRadius", `${config.cardRadius}px`);
}

function setTheme() {
  let card = document.querySelector(".card");
  if (config.isFrostyThemeEnabled) return card.classList.add("flavor-frosty");
  return card.classList.add("flavor-default");
}

function setFrostyBlur() {
  if (!config.isFrostyThemeEnabled) return;
  let frosted = document.querySelector(".flavor-frosty");
  frosted.style.setProperty("--cardBlur", `${config.cardBlur}px`);
}

function setFont() {
  if (config.isSystemFontEnabled)
    return document.body.style.setProperty("font-family", "var(--systemFont)");
  return;
}
