function onload() {
  api.system.observeData(function (systemData) {
    loadTime(systemData);
  });
  api.resources.observeData(function (resourcesData) {
    loadBattery(resourcesData);
  });
  applyConfiguration();
}

function loadTime(systemData) {
  time.init({
    refresh: 10000,
    twentyfour: systemData.isTwentyFourHourTimeEnabled,
    callback: function (time) {
      document.querySelector(
        ".card__entry"
      ).innerHTML = `It's ${time.dayText()}, ${time.monthText()} ${time.dateNth()}`;
      document.querySelectorAll(
        ".card__entry"
      )[2].innerHTML = `Current time ${time.hour()}:${time.minute()}`;
    },
  });
}

function loadBattery(resourcesData) {
  document.querySelectorAll('.card__entry')[1].innerHTML = `Battery life ${resourcesData.battery.percentage}%`;
}

function applyConfiguration() {
  isDateHidden();
  isBatteryHidden();
  isClockHidden();
  setCardProperties();
  setTheme();
  setFrostyBlur();
}

function isDateHidden() {
  if (config.isDateHidden) return (document.querySelector('.card__entry').style.display = "none");
  return;
}

function isBatteryHidden() {
  if (config.isBatteryHidden) return (document.querySelectorAll('.card__entry')[1].style.display = "none");
  return;
}

function isClockHidden() {
  if (config.isClockHidden) return (document.querySelectorAll('.card__entry')[2].style.display = "none");
  return;
}

function setCardProperties() {
  let root = document.querySelector(":root");
  root.style.setProperty("--cardHeight", `${config.cardHeight}%`);
  root.style.setProperty("--cardWidth", `${config.cardWidth}%`);
  root.style.setProperty("--cardRadius", `${config.cardRadius}px`);
}

function setTheme() {
  let card = document.querySelector(".card");
  if (config.isFrostyThemeEnabled) return card.classList.add("flavor--Frosty");
  return card.classList.add("flavor--Default");
}

function setFrostyBlur() {
  let frosted = document.querySelector(".flavor--Frosty");
  frosted.style.setProperty("--cardBlur", `${config.cardBlur}px`);
}
