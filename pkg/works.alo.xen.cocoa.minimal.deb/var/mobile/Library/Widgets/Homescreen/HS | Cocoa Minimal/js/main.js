const loadTime = (systemData) => {
  time.init({
    refresh: 5000,
    twentyfour: systemData.isTwentyFourHourTimeEnabled,
    callback: function (time) {
      document.getElementById(
        "date"
      ).textContent = `It's ${time.dayText()}, ${time.monthText()} ${time.dateNth()}`;
      document.getElementById(
        "time"
      ).textContent = `Current time ${time.hour()}:${time.minute()}`;
    },
  });
};

const setWicon = (weatherData) => {
  const weathericons = [
    "&#xf056;",
    "&#xf00e;",
    "&#xf073;",
    "&#xf01e;",
    "&#xf01e;",
    "&#xf017;",
    "&#xf017;",
    "&#xf017;",
    "&#xf015;",
    "&#xf01a;",
    "&#xf015;",
    "&#xf01a;",
    "&#xf01a;",
    "&#xf01b;",
    "&#xf00a;",
    "&#xf064;",
    "&#xf01b;",
    "&#xf015;",
    "&#xf017;",
    "&#xf063;",
    "&#xf014;",
    "&#xf021;",
    "&#xf062;",
    "&#xf050;",
    "&#xf050;",
    "&#xf076;",
    "&#xf013;",
    "&#xf031;",
    "&#xf002;",
    "&#xf031;",
    "&#xf002;",
    "&#xf02e;",
    "&#xf00d;",
    "&#xf083;",
    "&#xf00c;",
    "&#xf017;",
    "&#xf072;",
    "&#xf00e;",
    "&#xf00e;",
    "&#xf00e;",
    "&#xf01a;",
    "&#xf064;",
    "&#xf01b;",
    "&#xf064;",
    "&#xf00c;",
    "&#xf00e;",
    "&#xf01b;",
    "&#xf00e;",
    "&#xf077;",
  ];
  document.getElementById("wicon").innerHTML = `${
    weathericons[weatherData.now.condition.code]
  } ${weatherData.now.temperature.current}`;
};

const setWeatherCondition = (weatherData) => {
  document.getElementById("cond").textContent =
    weatherData.now.condition.description;
};

const loadWeather = (weatherData) => {
  setWicon(weatherData);
  setWeatherCondition(weatherData);
};

const loadBattery = (resourcesData) => {
  document.getElementById(
    "batt"
  ).textContent = `Battery life ${resourcesData.battery.percentage}%`;
};

const setCardProperties = () => {
  let root = document.querySelector(":root");
  root.style.setProperty("--cardHeight", `${config.cardHeight}%`);
  root.style.setProperty("--cardWidth", `${config.cardWidth}%`);
  root.style.setProperty("--cardRadius", `${config.cardRadius}px`);
};

const setFrostyBlur = () => {
  const frosted = document.querySelector(".flavor-frosty");
  frosted.style.setProperty("--cardBlur", `${config.cardBlur}px`);
};

const setFrostyTheme = () => {
  const card = document.querySelector(".card");
  card.classList.add("flavor-frosty");
  setFrostyBlur();
};

const setDefaultColors = () => {
  const card = document.querySelector(".card");
  card.classList.add("flavor-default");
  const defaultTheme = document.querySelector(".flavor-default");
  defaultTheme.style.setProperty("--cardColor", config.defaultCardColor);
  defaultTheme.style.setProperty("--holderColor", config.defaultHolderColor);
  defaultTheme.style.setProperty("--textColor", config.defaultTextColor);
};

const setSystemFontWeight = () => {
  document.body.style.setProperty("font-weight", config.fontWeight);
};

const setSystemFont = () => {
  document.body.style.setProperty("font-family", "var(--systemFont)");
  document
    .querySelector("#wicon")
    .style.setProperty("font-family", "weather, var(--systemFont)");
  setSystemFontWeight();
};

const applyConfiguration = () => {
  const configurationActions = [
    {
      condition: config.isDateHidden,
      success() {
        document.querySelector("#date").style.display = "none";
      },
      failure() {
        return null;
      },
    },
    {
      condition: config.isBatteryHidden,
      success() {
        document.querySelector("#batt").style.display = "none";
      },
      failure() {
        return null;
      },
    },
    {
      condition: config.isClockHidden,
      success() {
        document.querySelector("#time").style.display = "none";
      },
      failure() {
        return null;
      },
    },
    {
      condition: config.isWeatherHidden,
      success() {
        document.querySelector("#weather").style.display = "none";
      },
      failure() {
        return null;
      },
    },
    {
      condition: config.isFrostyThemeEnabled,
      success() {
        setFrostyTheme();
      },
      failure() {
        setDefaultColors();
      },
    },
    {
      condition: config.isSystemFontEnabled,
      success() {
        setSystemFont();
      },
      failure() {
        return null;
      },
    },
  ];

  setCardProperties();

  configurationActions.forEach((operation) => {
    operation.condition ? operation.success() : operation.failure();
  });
};

const perform = () => {
  api.system.observeData(function (systemData) {
    loadTime(systemData);
  });
  api.weather.observeData(function (weatherData) {
    loadWeather(weatherData);
  });
  api.resources.observeData(function (resourcesData) {
    loadBattery(resourcesData);
  });
  applyConfiguration();
};

document.addEventListener("DOMContentLoaded", perform);
