(() => {
  api.system.observeData(function (systemData) {
    loadTime(systemData);
  });
  api.weather.observeData(function (weatherData) {
    loadWeather(weatherData);
  });
  api.resources.observeData(function (resourcesData) {
    loadBattery(resourcesData);
  });
  applyConfiguration();
})();

function loadTime(systemData) {
  time.init({
    refresh: 5000,
    twentyfour: systemData.isTwentyFourHourTimeEnabled,
    callback: function (time) {
      document.getElementById(
        "date"
      ).textContent = `It's ${time.dayText()}, ${time.monthText()} ${time.dateNth()}`;
      document.getElementById(
        "time"
      ).textContent = `Current time ${time.hour()}:${time.minute()}`;
    },
  });
}

function loadWeather(weatherData) {
  setWicon(weatherData);
  setWeatherCondition(weatherData);
}

function loadBattery(resourcesData) {
  document.getElementById(
    "batt"
  ).textContent = `Battery life ${resourcesData.battery.percentage}%`;
}

function setWicon(weatherData) {
  const weathericons = [
    "&#xf056;",
    "&#xf00e;",
    "&#xf073;",
    "&#xf01e;",
    "&#xf01e;",
    "&#xf017;",
    "&#xf017;",
    "&#xf017;",
    "&#xf015;",
    "&#xf01a;",
    "&#xf015;",
    "&#xf01a;",
    "&#xf01a;",
    "&#xf01b;",
    "&#xf00a;",
    "&#xf064;",
    "&#xf01b;",
    "&#xf015;",
    "&#xf017;",
    "&#xf063;",
    "&#xf014;",
    "&#xf021;",
    "&#xf062;",
    "&#xf050;",
    "&#xf050;",
    "&#xf076;",
    "&#xf013;",
    "&#xf031;",
    "&#xf002;",
    "&#xf031;",
    "&#xf002;",
    "&#xf02e;",
    "&#xf00d;",
    "&#xf083;",
    "&#xf00c;",
    "&#xf017;",
    "&#xf072;",
    "&#xf00e;",
    "&#xf00e;",
    "&#xf00e;",
    "&#xf01a;",
    "&#xf064;",
    "&#xf01b;",
    "&#xf064;",
    "&#xf00c;",
    "&#xf00e;",
    "&#xf01b;",
    "&#xf00e;",
    "&#xf077;",
  ];
  document.getElementById("wicon").innerHTML = `${
    weathericons[weatherData.now.condition.code]
  } ${weatherData.now.temperature.current}`;
}

function setWeatherCondition(weatherData) {
  document.getElementById("cond").textContent =
    weatherData.now.condition.description;
}

function applyConfiguration() {
  isDateHidden();
  isBatteryHidden();
  isClockHidden();
  isWeatherHidden();
  setCardProperties();
  setTheme();
  setFrostyBlur();
  setFont();
  setSystemFontWeight();
}

function isDateHidden() {
  if (config.isDateHidden)
    return (document.getElementById("date").style.display = "none");
  return;
}

function isBatteryHidden() {
  if (config.isBatteryHidden)
    return (document.getElementById("batt").style.display = "none");
  return;
}

function isClockHidden() {
  if (config.isClockHidden)
    return (document.getElementById("time").style.display = "none");
  return;
}

function isWeatherHidden() {
  if (config.isWeatherHidden)
    return (document.getElementById("weather").style.display = "none");
  return;
}

function setCardProperties() {
  let root = document.querySelector(":root");
  root.style.setProperty("--cardHeight", `${config.cardHeight}%`);
  root.style.setProperty("--cardWidth", `${config.cardWidth}%`);
  root.style.setProperty("--cardRadius", `${config.cardRadius}px`);
}

function setTheme() {
  let card = document.querySelector(".card");
  if (config.isFrostyThemeEnabled) return card.classList.add("flavor-frosty");
  return card.classList.add("flavor-default");
}

function setFrostyBlur() {
  if (!config.isFrostyThemeEnabled) return;
  let frosted = document.querySelector(".flavor-frosty");
  frosted.style.setProperty("--cardBlur", `${config.cardBlur}px`);
}

function setFont() {
  if (config.isSystemFontEnabled) {
    document.body.style.setProperty("font-family", "var(--systemFont)");
    document
      .getElementById("wicon")
      .style.setProperty("font-family", "weather, var(--systemFont)");
    return;
  }
  return;
}

function setSystemFontWeight() {
  if (!config.isSystemFontEnabled) return;
  switch (config.fontWeight) {
    case 1:
      document.body.style.setProperty("font-weight", 100);
      break;
    case 2:
      document.body.style.setProperty("font-weight", 200);
      break;
    case 3:
      document.body.style.setProperty("font-weight", 300);
      break;
    case 4:
      document.body.style.setProperty("font-weight", 400);
      break;
    case 5:
      document.body.style.setProperty("font-weight", 500);
      break;
    case 6:
      document.body.style.setProperty("font-weight", 600);
      break;
    case 7:
      document.body.style.setProperty("font-weight", 700);
      break;
    case 8:
      document.body.style.setProperty("font-weight", 800);
      break;
    case 9:
      document.body.style.setProperty("font-weight", 900);
      break;
  }
}
