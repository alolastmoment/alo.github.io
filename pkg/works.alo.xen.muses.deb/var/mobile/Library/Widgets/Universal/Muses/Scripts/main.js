let scrobbleIsDragging = false;


/**
 * This function is called when the widget finishes loading.
 */
function onload() {
    // Register for media data changes
    api.media.observeData(function (newData) {
        // `newData` is equivalent to `api.media`

        // Update elapsed/length state
        handleTrackTimes(newData.nowPlaying.elapsed);

});
        

    // Elapsed time observer - needed for live updates to the elapsed time shown in the UI
    api.media.observeElapsedTime(function (newElapsedTime) {
        // Call update function with the time, and the same length
        handleTrackTimes(newElapsedTime);
        
});

}

/**
 * Handles updating the UI for the given track timings
 * @param {*} elapsed
 * @param {*} length
 */
function handleTrackTimes(elapsed) {
    

    const elapsedContent = secondsToFormatted(elapsed);
    document.getElementById('elapsedTime').innerHTML = elapsedContent;
   
}


/**
 * Generates a formatted time for the seconds specified
 * @param {*} seconds
 */
function secondsToFormatted(seconds) {
    if (seconds === 0) return '0:00';

    const isNegative = seconds < 0;
    if (isNegative) return '0:00';

    seconds = Math.abs(seconds);
    const hours = Math.floor(seconds / 60 / 60);
    const minutes = Math.floor(seconds / 60) - (hours * 60);
    const secs = Math.floor(seconds - (minutes * 60) - (hours * 60 * 60));

    if (hours > 0) {
        return hours + ':' + (minutes < 10 ? '0' : '') + minutes + ':' + (secs < 10 ? '0' : '') + secs;
    } else {
        return minutes + ':' + (secs < 10 ? '0' : '') + secs;
    }
}



