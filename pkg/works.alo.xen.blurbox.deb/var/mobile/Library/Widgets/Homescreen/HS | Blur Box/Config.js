var boxWidth = 310; // Enter the box width. This will be in pixels;
var boxHeight = 420; // Enter the box height. This will be in pixels;
var boxColor = "rgba(255,255,255,0.03)"; // Enter the color in rgba() format. These mean (Red, Green, Blue, Alpha/Opacity)
var boxBlur = 15; // Enter the blur value. Larger values mean more blur.
var boxBorderRadius = 20; // Enter the border value. Larger values mean more rounder edges.
