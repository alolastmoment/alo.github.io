function onload() {
    const element = document.getElementById('time');

    const now = new Date().toLocaleTimeString("en-US");
    const parts = now.split(" ");

    const timeparts = parts[0].split(":");

if(typeof parts[1] != "undefined"){
    element.innerHTML = timeparts[0] + ":" + timeparts[1] + " " + parts[1];
} else {
element.innerHTML = timeparts[0] + ":" + timeparts[1] ;
}

    var todayDate = new Date();
    var dateParts = (todayDate.toDateString()).split(" ");
    console.log(dateParts);

    const dateElement = document.getElementById('date');
    dateElement.innerHTML = dateParts[1] + " " + dateParts[2] + ", " + dateParts[0];
}

function initTime() {

    // Short text input
    const shortText = config.textShort;
    
    if(shortText.trim() == ""){
        $('#heartImg').attr('src', 'Stuff/heart.png');
    } else {
        $('#heartImg').attr('src', 'Stuff/' + shortText.toLowerCase() + '.png');
    }

    

    onload();
    setInterval(onload, 1000);
}