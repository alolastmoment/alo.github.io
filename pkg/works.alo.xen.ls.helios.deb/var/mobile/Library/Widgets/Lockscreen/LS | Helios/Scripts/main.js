function onload() {
    const element = document.getElementById('time');

    const now = new Date().toLocaleTimeString();
    const parts = now.split(" ");

    const timeparts = parts[0].split(":");

    element.innerHTML = timeparts[0] + ":" + timeparts[1] + " " + parts[1];

    var todayDate = new Date();
    var dateParts = (todayDate.toDateString()).split(" ");
    console.log(dateParts);

    const dateElement = document.getElementById('date');
    dateElement.innerHTML = dateParts[1] + " " + dateParts[2] + ", " + dateParts[0];
}

function initTime() {

    // Short text input
    const shortText = config.textShort;
    
    if(shortText.trim() == ""){
        $('#heartImg').attr('src', 'Stuff/heart.png');
    } else {
        $('#heartImg').attr('src', 'Stuff/' + shortText.toLowerCase() + '.png');
    }

    

    onload();
    setInterval(onload, 1000);
}