var Clock = "12h"; // choose between "12h" or "24h"
var Lang = "en"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh"
var dotsColor2 = "#e0c1ce"; // enter hex or rgba(). responsible for date dot
var dotsColor3 = "#ffffaf"; // enter hex or rgba(). responsible for weather dot
var dotsColor4 = "#b5efc4"; // enter hex or rgba(). responsible for battery dot
