(function () {
  api.system.observeData(function (systemData) {
    loadTime(systemData);
  });
  api.weather.observeData(function (weatherData) {
    loadWeather(weatherData);
  });
  api.resources.observeData(function (resourcesData) {
    checkBattery(resourcesData);
  });
})();
