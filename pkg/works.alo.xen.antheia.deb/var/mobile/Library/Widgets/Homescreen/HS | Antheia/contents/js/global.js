var doc = document;

var container = doc.getElementById("container"),
  greet = doc.getElementById("greet"),
  date = doc.getElementById("date"),
  weatherContainer = doc.getElementById("weatherContainer"),
  weather = doc.getElementById("weather"),
  battery = doc.getElementById("battery");

function loadTime(systemData) {
  var twelveHour = systemData.isTwentyFourHourTimeEnabled ? false : true;
  theTime({
    amPm: twelveHour,
    addZero: true,
    done: function (timeObj) {
      date.innerHTML = `${timeObj.dayText()}, ${timeObj.monthText()} ${timeObj.dateNth()}`;
    },
  });
}

function checkBattery(resourceData) {
  var battState;
  if (resourceData.battery.state === 0) {
    battState = "unplugged";
  } else if (resourceData.battery.state === 1) {
    battState = "charging";
  } else {
    battState = "fully charged";
  }
  battery.innerHTML = `${battState} ${resourceData.battery.percentage}%`;
}

function loadWeather(weatherData) {
  weather.innerHTML = `${weatherData.now.temperature.current}&deg${weatherData.units.temperature} | ${weatherData.now.condition.description}`;
}

greet.innerHTML = `hello, ${config.usr}`;

if (config.switch_sysfont) {
  let sysfont = doc.createElement('style');
  sysfont.innerHTML = `
  #widget {
   font-family: system-ui, "Helvetica Neue", Arial, sans-serif;
   font-weight: 400;
  }
  `;
  doc.body.appendChild(sysfont);
}
if (config.switch_hw) {
  weatherContainer.style.display = "none";
  container.classList.toggle("hiddenWeather");
}

let addHeight = doc.createElement("style");
switch (window.innerHeight) {
  case 667:
  case 736:
    addHeight.innerHTML = `.container {
      height: calc(30% + ${config["sl-ah"]}px);
    }
    .hiddenWeather {
      height: calc(27% + ${config["sl-ah"]}px)
    }`;
    break;
  default:
    addHeight.innerHTML = `.container {
      height: calc(26% + 2.5*${config["sl-ah"]}px);
    }
    .hiddenWeather {
      height: calc(23.5% +${config["sl-ah"]}px)
    }`;
    break;
}
doc.body.appendChild(addHeight);

let sheet = doc.createElement("style");
sheet.innerHTML = `:root{--textColor:${config["c-text"]};--bgColor:${config["c-bg"]};--br:${config["sl-br"]}px ${config["sl-br"]}px 0 0;--blur:${config["sl-blur"]}px;}#R1:before,#R2{background-color:${config.gdc};}#R3:before,#R4{background-color:${config.ddc};}#R5:before,#R6{background-color:${config.wdc};}#R7:before,#R8{background-color:${config.bdc};}`;
doc.body.appendChild(sheet);
