var username = "unlucki"; // enter name or alias
var hideWeather = false; // set to true to hide weather
var dotsColor = "#b5d8ef"; // enter hex or rgba(). responsible for greet dot
var dotsColor2 = "#e0c1ce"; // enter hex or rgba(). responsible for date dot
var dotsColor3 = "#ffffaf"; // enter hex or rgba(). responsible for weather dot
var dotsColor4 = "#b5efc4"; // enter hex or rgba(). responsible for battery dot
