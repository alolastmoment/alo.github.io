var username = "unlucki"; //enter name or alias
var hideWeather = false;
var dotsColor = "#b5d8ef"; // enter hex or rgba()
var dotsColor2 = "#e0c1ce"; // enter hex or rgba()
var dotsColor3 = "#ffffaf"; // enter hex or rgba()
var dotsColor4 = "#b5efc4"; // enter hex or rgba()
