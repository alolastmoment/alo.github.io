var ringsColor = "#FFFFFF"; 
var textColor = "#FFFFFF"; 
var hourHandColor = "#FFFFFF"; 
var minuteHandColor = "#324d63"; 
var leftCircleColor = "#FFFFFFF"; 
var rightCircleColor = "#FFFFFF"; 
var centerCircleColor = "#324d63"; 
