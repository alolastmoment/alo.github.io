function onload() {
    const element = document.getElementById('time');

    const now = new Date().toLocaleTimeString('en-US',{ // you can skip the first argument
  minutes: "2-digit",
});
    const parts = now.split(" ");

    const timeparts = parts[0].split(":");

    element.innerHTML = "<span class='hour'>"+timeparts[0] + "</span>" + timeparts[1];

    var todayDate = new Date();
    var dateParts = (todayDate.toDateString()).split(" ");
    
    
    /*const dateElement = document.getElementById('date');
    dateElement.innerHTML = dateParts[1]+" "+dateParts[2]+", "+dateParts[0];*/
}

function initTime(){
 onload();
setInterval(onload, 1000);
}

function pad(n){return n<10 ? '0'+n : n}