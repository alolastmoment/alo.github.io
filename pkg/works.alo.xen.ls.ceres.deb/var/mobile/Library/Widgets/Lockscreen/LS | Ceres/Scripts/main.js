/**
 * Called when the document has loaded
 */
function onload() {
    const element = document.getElementById('time');

    const now = new Date().toLocaleTimeString('en-US');
    const parts = now.split(" ");

    const timeparts = parts[0].split(":");

    if (typeof parts[1] != "undefined") {
        element.innerHTML = timeparts[0] + ":" + timeparts[1] + " " + parts[1];
    } else {
        element.innerHTML = timeparts[0] + ":" + timeparts[1];
    }


    var todayDate = new Date();
    var dateParts = (todayDate.toDateString()).split(" ");
    console.log(dateParts);

    const dateElement = document.getElementById('date');
    dateElement.innerHTML = dateParts[2] + " " + dateParts[1];

    const yearElement = document.getElementById('year');
    yearElement.innerHTML = dateParts[3];

    const dayElement = document.getElementById('day');
    dayElement.innerHTML = dateParts[0];

    let lpmflag;
    api.system.observeData(function (newData) {

        if (newData.isLowPowerModeEnabled) {
            lpmflag = true;
        } else {
            lpmflag = false;
        }
    });

    api.resources.observeData(function (newData) {



        let battPerc = document.getElementById("batteryLevel");
        battPerc.innerHTML = "Battery @ " + newData.battery.percentage + "%";

        let battPill = document.getElementById("batteryPill");

        let battState = document.getElementById("batteryState");

        if (lpmflag) {
            battState.innerHTML = 'Low Power Mode';
            battPill.className = "battery low-power";
        } else {

            // Generate text to display underneath the current percent
            let underneathText = '';
            battPill.className = "battery normal";
            if (newData.battery.state === 2) {
                battState.innerHTML = 'Fully charged';
                battPill.className = "battery charging";
            } else if (newData.battery.state === 1) {
                battState.innerHTML = 'Charging';
                battPill.className = "battery charging";
            } else if (newData.battery.state === 0) {
                battState.innerHTML = 'Discharging';

                if (newData.battery.percentage <= 20) {
                    battPill.className = "battery discharging-20";
                }
            }
        }



        $('.normal').attr('style', 'background-color:' + config.colorSettingNormal + ';color:' + config.colorSettingBattery);

        $('.charging').attr('style', 'background-color:' + config.colorSettingCharging + ';color:' + config.colorSettingBattery);

        $('.discharging-20').attr('style', 'background-color:' + config.colorSettingDischarging20 + ';color:' + config.colorSettingBattery);

        $('.low-power').attr('style', 'background-color:' + config.colorSettingLPM + ';color:' + config.colorSettingBattery);


        $('.time').attr('style', 'color:' + config.colorSettingTime);

        $('.weatherCond').attr('style', 'color:' + config.colorSettingWeatherCond);

        $('.row3').attr('style', 'color:' + config.colorSettingRow3);


    });

}

function initTime() {

    onload();

    $('.normal').attr('style', 'background-color:' + config.colorSettingNormal + ';color:' + config.colorSettingBattery);

    $('.charging').attr('style', 'background-color:' + config.colorSettingCharging + ';color:' + config.colorSettingBattery);

    $('.discharging-20').attr('style', 'background-color:' + config.colorSettingDischarging20 + ';color:' + config.colorSettingBattery);

    $('.low-power').attr('style', 'background-color:' + config.colorSettingLPM + ';color:' + config.colorSettingBattery);


    $('.time').attr('style', 'color:' + config.colorSettingTime);

    $('.weatherCond').attr('style', 'color:' + config.colorSettingWeatherCond);

    $('.row3').attr('style', 'color:' + config.colorSettingRow3);

    $('.circle').attr('style', 'background-color:' + config.colorSettingCircle);

    switch (config.boltColor) {
        case 'boltBlack':

            $('.battImg').attr('src', 'Stuff/boltBlack.png');
            break;

        case 'boltWhite':

            $('.battImg').attr('src', 'Stuff/boltWhite.png');
            break;

    }

    setInterval(onload, 1000);
}